/**
 * Módulo para visualização de gráficos
 */
const visualizacaoGraficos = {
    // Configurações padrão
    config: {
        periodoSelecionado: 'mensal'
    },
    
    /**
     * Inicializa o módulo
     */
    init: function() {
        // Carregar configurações salvas
        this.carregarConfiguracoes();
        
        // Configurar eventos
        document.getElementById('periodoGrafico').addEventListener('change', () => {
            this.config.periodoSelecionado = document.getElementById('periodoGrafico').value;
            this.salvarConfiguracoes();
            this.atualizarGraficoFluxo();
        });
        
        // Inicializar gráficos
        this.atualizarGraficoFluxo();
        this.atualizarGraficoCategorias();
        this.atualizarGraficoEvolucaoSaldo();
    },
    
    /**
     * Carrega configurações do localStorage
     */
    carregarConfiguracoes: function() {
        const configSalva = localStorage.getItem('visualizacao_graficos_config');
        if (configSalva) {
            try {
                const config = JSON.parse(configSalva);
                this.config = { ...this.config, ...config };
                
                // Atualizar seletor de período
                document.getElementById('periodoGrafico').value = this.config.periodoSelecionado;
            } catch (e) {
                console.error('Erro ao carregar configurações de visualização de gráficos:', e);
            }
        }
    },
    
    /**
     * Salva configurações no localStorage
     */
    salvarConfiguracoes: function() {
        localStorage.setItem('visualizacao_graficos_config', JSON.stringify(this.config));
    },
    
    /**
     * Atualiza o gráfico de fluxo de caixa
     */
    atualizarGraficoFluxo: function() {
        const ctx = document.getElementById('fluxoChart').getContext('2d');
        
        // Destruir gráfico anterior se existir
        if (window.fluxoChart) {
            window.fluxoChart.destroy();
        }
        
        // Obter todos os dados
        const todosDados = carregarDados();
        
        // Obter período selecionado
        const periodo = this.config.periodoSelecionado;
        
        // Preparar dados para o gráfico
        const dadosGrafico = this.prepararDadosGrafico(todosDados, periodo);
        
        // Criar gráfico
        window.fluxoChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: dadosGrafico.labels,
                datasets: [
                    {
                        label: 'A Receber',
                        data: dadosGrafico.receber,
                        backgroundColor: 'rgba(40, 167, 69, 0.7)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'A Pagar',
                        data: dadosGrafico.pagar,
                        backgroundColor: 'rgba(220, 53, 69, 0.7)',
                        borderColor: 'rgba(220, 53, 69, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Saldo',
                        data: dadosGrafico.saldo,
                        type: 'line',
                        backgroundColor: 'rgba(0, 123, 255, 0.5)',
                        borderColor: 'rgba(0, 123, 255, 1)',
                        borderWidth: 2,
                        fill: false,
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                if (typeof configuracoes !== 'undefined') {
                                    return configuracoes.formatarValor(value);
                                } else {
                                    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                }
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    if (typeof configuracoes !== 'undefined') {
                                        label += configuracoes.formatarValor(context.parsed.y);
                                    } else {
                                        label += context.parsed.y.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                    }
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    },
    
    /**
     * Prepara dados para o gráfico de fluxo de caixa
     * @param {Object} dados Dados do fluxo de caixa
     * @param {String} periodo Período selecionado (diario, semanal, mensal, anual)
     * @returns {Object} Dados formatados para o gráfico
     */
    prepararDadosGrafico: function(dados, periodo) {
        // Obter todas as transações
        const todasTransacoes = [
            ...dados.receber.map(item => ({ ...item, tipo: 'receber' })),
            ...dados.pagar.map(item => ({ ...item, tipo: 'pagar' }))
        ];
        
        // Definir formato de agrupamento baseado no período
        let formatoData;
        let formatoLabel;
        
        switch (periodo) {
            case 'diario':
                formatoData = data => data.toISOString().split('T')[0];
                formatoLabel = data => {
                    const d = new Date(data);
                    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
                };
                break;
            case 'semanal':
                formatoData = data => {
                    const d = new Date(data);
                    const primeiroDiaAno = new Date(d.getFullYear(), 0, 1);
                    const semana = Math.ceil(((d - primeiroDiaAno) / 86400000 + primeiroDiaAno.getDay() + 1) / 7);
                    return `${d.getFullYear()}-W${semana}`;
                };
                formatoLabel = data => {
                    const partes = data.split('-W');
                    return `Sem ${partes[1]}/${partes[0]}`;
                };
                break;
            case 'anual':
                formatoData = data => new Date(data).getFullYear().toString();
                formatoLabel = data => data;
                break;
            case 'mensal':
            default:
                formatoData = data => {
                    const d = new Date(data);
                    return `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}`;
                };
                formatoLabel = data => {
                    const [ano, mes] = data.split('-');
                    const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
                    return `${meses[parseInt(mes) - 1]}/${ano}`;
                };
                break;
        }
        
        // Agrupar transações por período
        const dadosPorPeriodo = {};
        
        todasTransacoes.forEach(item => {
            const data = new Date(item.data);
            const chave = formatoData(data);
            
            if (!dadosPorPeriodo[chave]) {
                dadosPorPeriodo[chave] = {
                    receber: 0,
                    pagar: 0
                };
            }
            
            if (item.tipo === 'receber') {
                dadosPorPeriodo[chave].receber += item.valor;
            } else {
                dadosPorPeriodo[chave].pagar += item.valor;
            }
        });
        
        // Ordenar períodos
        const periodos = Object.keys(dadosPorPeriodo).sort();
        
        // Preparar dados para o gráfico
        const labels = periodos.map(formatoLabel);
        const receber = periodos.map(p => dadosPorPeriodo[p].receber);
        const pagar = periodos.map(p => dadosPorPeriodo[p].pagar);
        const saldo = periodos.map(p => dadosPorPeriodo[p].receber - dadosPorPeriodo[p].pagar);
        
        return {
            labels,
            receber,
            pagar,
            saldo
        };
    },
    
    /**
     * Atualiza o gráfico de categorias
     */
    atualizarGraficoCategorias: function() {
        const ctx = document.getElementById('categoriasChart').getContext('2d');
        
        // Destruir gráfico anterior se existir
        if (window.categoriasChart) {
            window.categoriasChart.destroy();
        }
        
        // Obter todos os dados
        const todosDados = carregarDados();
        
        // Obter categorias e valores
        const categorias = {};
        
        // Processar pagamentos
        todosDados.pagar.forEach(item => {
            const categoria = item.categoria || 'outros';
            if (!categorias[categoria]) {
                categorias[categoria] = 0;
            }
            categorias[categoria] += item.valor;
        });
        
        // Preparar dados para o gráfico
        const labels = Object.keys(categorias);
        const valores = Object.values(categorias);
        
        // Cores para as categorias
        const cores = {
            alimentacao: 'rgba(40, 167, 69, 0.7)',
            logistica: 'rgba(0, 123, 255, 0.7)',
            salarios: 'rgba(111, 66, 193, 0.7)',
            impostos: 'rgba(220, 53, 69, 0.7)',
            marketing: 'rgba(253, 126, 20, 0.7)',
            vendas: 'rgba(32, 201, 151, 0.7)',
            outros: 'rgba(108, 117, 125, 0.7)'
        };
        
        const backgroundColors = labels.map(cat => cores[cat] || 'rgba(108, 117, 125, 0.7)');
        const borderColors = backgroundColors.map(cor => cor.replace('0.7', '1'));
        
        // Criar gráfico
        window.categoriasChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels.map(this.formatarLabelCategoria),
                datasets: [{
                    label: 'Gastos por Categoria',
                    data: valores,
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            boxWidth: 15,
                            padding: 10
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed !== null) {
                                    if (typeof configuracoes !== 'undefined') {
                                        label += configuracoes.formatarValor(context.parsed);
                                    } else {
                                        label += context.parsed.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                    }
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    },
    
    /**
     * Formata o label da categoria para exibição
     * @param {String} categoria Código da categoria
     * @returns {String} Nome formatado da categoria
     */
    formatarLabelCategoria: function(categoria) {
        const nomes = {
            alimentacao: 'Alimentação',
            logistica: 'Logística',
            salarios: 'Salários',
            impostos: 'Impostos',
            marketing: 'Marketing',
            vendas: 'Vendas',
            outros: 'Outros'
        };
        
        return nomes[categoria] || categoria.charAt(0).toUpperCase() + categoria.slice(1);
    },
    
    /**
     * Atualiza o gráfico de evolução do saldo
     */
    atualizarGraficoEvolucaoSaldo: function() {
        const ctx = document.getElementById('evolucaoSaldoChart').getContext('2d');
        
        // Destruir gráfico anterior se existir
        if (window.evolucaoSaldoChart) {
            window.evolucaoSaldoChart.destroy();
        }
        
        // Obter todos os dados
        const todosDados = carregarDados();
        
        // Obter saldo inicial
        let saldoInicial = 0;
        if (typeof configuracoes !== 'undefined') {
            saldoInicial = configuracoes.obterSaldoInicial().valor;
        }
        
        // Obter todas as datas únicas
        const todasTransacoes = [
            ...todosDados.receber.map(item => ({ ...item, tipo: 'receber' })),
            ...todosDados.pagar.map(item => ({ ...item, tipo: 'pagar' }))
        ];
        
        // Ordenar por data
        todasTransacoes.sort((a, b) => new Date(a.data) - new Date(b.data));
        
        // Agrupar por mês
        const dadosPorMes = {};
        
        todasTransacoes.forEach(item => {
            const data = new Date(item.data);
            const mesAno = `${data.getFullYear()}-${(data.getMonth() + 1).toString().padStart(2, '0')}`;
            
            if (!dadosPorMes[mesAno]) {
                dadosPorMes[mesAno] = {
                    receber: 0,
                    pagar: 0
                };
            }
            
            if (item.tipo === 'receber') {
                dadosPorMes[mesAno].receber += item.valor;
            } else {
                dadosPorMes[mesAno].pagar += item.valor;
            }
        });
        
        // Calcular saldo acumulado
        const labels = Object.keys(dadosPorMes).sort();
        const saldos = [];
        let saldoAcumulado = saldoInicial;
        
        labels.forEach(mesAno => {
            saldoAcumulado += dadosPorMes[mesAno].receber - dadosPorMes[mesAno].pagar;
            saldos.push(saldoAcumulado);
        });
        
        // Formatar labels para exibição
        const labelsFormatados = labels.map(mesAno => {
            const [ano, mes] = mesAno.split('-');
            const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            return `${meses[parseInt(mes) - 1]}/${ano}`;
        });
        
        // Criar gráfico
        window.evolucaoSaldoChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelsFormatados,
                datasets: [{
                    label: 'Saldo Acumulado',
                    data: saldos,
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 2,
                    fill: false,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            boxWidth: 15,
                            padding: 10
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    if (typeof configuracoes !== 'undefined') {
                                        label += configuracoes.formatarValor(context.parsed.y);
                                    } else {
                                        label += context.parsed.y.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                    }
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                if (typeof configuracoes !== 'undefined') {
                                    return configuracoes.formatarValor(value);
                                } else {
                                    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                }
                            }
                        }
                    }
                }
            }
        });
    }
};

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    visualizacaoGraficos.init();
});
