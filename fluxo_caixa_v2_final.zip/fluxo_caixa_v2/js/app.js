// Variáveis globais
let dadosFluxo = { receber: [], pagar: [] };
let fluxoChart;
let projecaoChart;
let categoriasChart;
let evolucaoSaldoChart;
let periodoSelecionado = 'mensal';
let detalhesGraficoPeriodo = null;
let usuarioLogado = null;

// Inicialização quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Verificar login se o sistema de login estiver ativo
    if (document.getElementById('login-container')) {
        verificarLogin();
    } else {
        inicializarSistema();
    }
});

// Verificar se o usuário está logado
function verificarLogin() {
    usuarioLogado = localStorage.getItem('usuario_logado');
    
    if (usuarioLogado) {
        try {
            usuarioLogado = JSON.parse(usuarioLogado);
            document.getElementById('usuario-nome').textContent = usuarioLogado.nome;
            document.getElementById('login-container').classList.add('d-none');
            document.getElementById('app-container').classList.remove('d-none');
            inicializarSistema();
        } catch (e) {
            console.error('Erro ao verificar login:', e);
            localStorage.removeItem('usuario_logado');
            usuarioLogado = null;
        }
    } else {
        document.getElementById('login-container').classList.remove('d-none');
        document.getElementById('app-container').classList.add('d-none');
    }
}

// Inicializar o sistema
function inicializarSistema() {
    // Inicializar configurações
    if (typeof configuracoes !== 'undefined') {
        configuracoes.init();
        configuracoes.aplicarConfiguracoes();
    }
    
    // Inicializar módulo de saldo e projeção
    if (typeof saldoProjecao !== 'undefined') {
        saldoProjecao.init();
    }
    
    // Inicializar módulo de parcelamentos
    if (typeof parcelamentos !== 'undefined') {
        parcelamentos.init();
    }
    
    // Carregar dados
    carregarDadosIniciais();
    
    // Configurar eventos
    configurarEventos();
    
    // Configurar data atual para filtros
    configurarDatasIniciais();
    
    // Ajustar tamanho dos gráficos quando a janela for redimensionada
    window.addEventListener('resize', function() {
        if (fluxoChart) {
            fluxoChart.resize();
        }
        if (projecaoChart) {
            projecaoChart.resize();
        }
        if (categoriasChart) {
            categoriasChart.resize();
        }
        if (evolucaoSaldoChart) {
            evolucaoSaldoChart.resize();
        }
    });
}

// Carregar dados iniciais
function carregarDadosIniciais() {
    dadosFluxo = carregarDados();
    
    // Atualizar tabelas
    atualizarTabelas();
    
    // Atualizar resumo
    atualizarResumo();
    
    // Atualizar gráfico
    atualizarGrafico();
    
    // Atualizar saldo do dia
    atualizarSaldoDia();
    
    // Atualizar projeção
    atualizarProjecao();
    
    // Atualizar próximos vencimentos
    atualizarProximosVencimentos();
    
    // Atualizar gráficos adicionais
    atualizarGraficoCategorias();
    atualizarGraficoEvolucaoSaldo();
}

// Configurar eventos
function configurarEventos() {
    // Botão de nova transação
    document.getElementById('btnNovaTransacao').addEventListener('click', abrirModalNovaTransacao);
    
    // Botão de salvar transação
    document.getElementById('btnSalvarTransacao').addEventListener('click', salvarTransacao);
    
    // Botões de filtro
    document.getElementById('btnAplicarFiltro').addEventListener('click', aplicarFiltro);
    document.getElementById('btnLimparFiltro').addEventListener('click', limparFiltro);
    
    // Botão de limpar todas as transações
    document.getElementById('btnLimparTudo').addEventListener('click', confirmarLimparTudo);
    
    // Botões de exportar/importar
    document.getElementById('btnExportarCSV').addEventListener('click', exportarCSV);
    document.getElementById('btnImportarCSV').addEventListener('click', function() {
        document.getElementById('importarCSVInput').click();
    });
    
    document.getElementById('importarCSVInput').addEventListener('change', importarCSV);
    
    // Seletor de período do gráfico
    document.getElementById('periodoGrafico').addEventListener('change', function() {
        periodoSelecionado = this.value;
        atualizarGrafico();
    });
    
    // Botão de atualizar projeção
    document.getElementById('btnAtualizarProjecao').addEventListener('click', function() {
        const meses = parseInt(document.getElementById('mesesProjecao').value);
        atualizarProjecao(meses);
    });
    
    // Checkbox de transação parcelada
    document.getElementById('transacaoParcelada').addEventListener('change', function() {
        if (this.checked) {
            alert('Para criar uma transação parcelada, acesse a página de Parcelamentos após salvar esta transação.');
        }
    });
    
    // Botão de alternar tema
    document.getElementById('btnAlternarTema').addEventListener('click', alternarTema);
    
    // Botão de logout (se existir)
    const btnLogout = document.getElementById('btnLogout');
    if (btnLogout) {
        btnLogout.addEventListener('click', fazerLogout);
    }
    
    // Botão de login (se existir)
    const btnLogin = document.getElementById('btnLogin');
    if (btnLogin) {
        btnLogin.addEventListener('click', fazerLogin);
    }
    
    // Filtro de intervalo de datas predefinido
    document.getElementById('filtroIntervaloPredefinido').addEventListener('change', aplicarIntervaloPredefinido);
    
    // Filtro de categoria
    document.getElementById('filtroCategoria').addEventListener('change', function() {
        aplicarFiltro();
    });
}

// Configurar datas iniciais para filtros
function configurarDatasIniciais() {
    const hoje = new Date();
    const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    const fimMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
    
    // Formatar datas para o input date
    const inicioFormatado = formatarDataParaInput(inicioMes);
    const fimFormatado = formatarDataParaInput(fimMes);
    
    // Definir valores nos inputs
    document.getElementById('filtroDataInicio').value = inicioFormatado;
    document.getElementById('filtroDataFim').value = fimFormatado;
    
    // Definir data atual para nova transação
    document.getElementById('transacaoData').value = formatarDataParaInput(hoje);
}

// Formatar data para input (YYYY-MM-DD)
function formatarDataParaInput(data) {
    const ano = data.getFullYear();
    const mes = (data.getMonth() + 1).toString().padStart(2, '0');
    const dia = data.getDate().toString().padStart(2, '0');
    return `${ano}-${mes}-${dia}`;
}

// Abrir modal de nova transação
function abrirModalNovaTransacao() {
    // Limpar formulário
    document.getElementById('formTransacao').reset();
    document.getElementById('transacaoId').value = '';
    
    // Definir data atual
    document.getElementById('transacaoData').value = formatarDataParaInput(new Date());
    
    // Atualizar símbolo da moeda
    if (typeof configuracoes !== 'undefined') {
        const configMoeda = configuracoes.obterMoeda();
        document.getElementById('simboloMoedaTransacao').textContent = configMoeda.simbolo;
    }
    
    // Atualizar título do modal
    document.getElementById('modalTransacaoLabel').textContent = 'Nova Transação';
    
    // Abrir modal
    const modal = new bootstrap.Modal(document.getElementById('modalTransacao'));
    modal.show();
}

// Salvar transação
function salvarTransacao() {
    // Validar formulário
    const form = document.getElementById('formTransacao');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    // Obter dados do formulário
    const id = document.getElementById('transacaoId').value;
    const tipo = document.getElementById('transacaoTipo').value;
    const data = document.getElementById('transacaoData').value;
    const valor = parseFloat(document.getElementById('transacaoValor').value);
    const referencia = document.getElementById('transacaoReferencia').value;
    const categoria = document.getElementById('transacaoCategoria').value;
    const parcelada = document.getElementById('transacaoParcelada').checked;
    
    // Criar objeto de transação
    const transacao = {
        data: data,
        valor: valor,
        referencia: referencia,
        categoria: categoria
    };
    
    // Adicionar ou atualizar transação
    if (id) {
        // Atualizar transação existente
        if (tipo === 'receber') {
            atualizarTransacao(dadosFluxo.receber, id, transacao);
        } else {
            atualizarTransacao(dadosFluxo.pagar, id, transacao);
        }
    } else {
        // Adicionar nova transação
        if (tipo === 'receber') {
            dadosFluxo.receber.push(transacao);
        } else {
            dadosFluxo.pagar.push(transacao);
        }
    }
    
    // Salvar dados
    salvarDados(dadosFluxo);
    
    // Atualizar interface
    atualizarTabelas();
    atualizarResumo();
    atualizarGrafico();
    atualizarSaldoDia();
    atualizarProjecao();
    atualizarProximosVencimentos();
    atualizarGraficoCategorias();
    atualizarGraficoEvolucaoSaldo();
    
    // Fechar modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('modalTransacao'));
    modal.hide();
    
    // Redirecionar para página de parcelamentos se for transação parcelada
    if (parcelada) {
        setTimeout(function() {
            window.location.href = 'parcelamentos.html';
        }, 500);
    }
}

// Atualizar transação existente
function atualizarTransacao(lista, id, transacao) {
    // Converter id para número, pois vem como string do formulário
    const index = parseInt(id);
    
    // Verificar se o índice é válido
    if (index >= 0 && index < lista.length) {
        // Garantir que a data seja tratada corretamente
        if (transacao.data) {
            // Usar a data exatamente como foi selecionada, sem ajustes de timezone
            // A data já vem no formato YYYY-MM-DD do input
            transacao.data = transacao.data;
        }
        
        // Atualizar a transação mantendo outros campos que possam existir
        lista[index] = { ...lista[index], ...transacao };
        
        console.log('Transação atualizada com sucesso:', lista[index]);
    } else {
        console.error('Índice inválido ao atualizar transação:', index);
    }
}

// Editar transação
function editarTransacao(tipo, index) {
    let transacao;
    
    if (tipo === 'receber') {
        transacao = dadosFluxo.receber[index];
    } else {
        transacao = dadosFluxo.pagar[index];
    }
    
    if (!transacao) return;
    
    // Preencher formulário
    document.getElementById('transacaoId').value = index; // Usar o índice como ID
    document.getElementById('transacaoTipo').value = tipo;
    document.getElementById('transacaoValor').value = transacao.valor;
    document.getElementById('transacaoReferencia').value = transacao.referencia;
    
    // Definir categoria se existir
    if (transacao.categoria) {
        document.getElementById('transacaoCategoria').value = transacao.categoria;
    } else {
        document.getElementById('transacaoCategoria').value = 'outros';
    }
    
    // Definir data exatamente como está armazenada
    document.getElementById('transacaoData').value = transacao.data;
    
    // Atualizar título do modal
    document.getElementById('modalTransacaoLabel').textContent = 'Editar Transação';
    
    // Abrir modal
    const modal = new bootstrap.Modal(document.getElementById('modalTransacao'));
    modal.show();
}

// Confirmar exclusão de transação
function confirmarExclusao(tipo, index) {
    document.getElementById('mensagemConfirmacao').textContent = 'Tem certeza que deseja excluir esta transação?';
    
    const modal = new bootstrap.Modal(document.getElementById('modalConfirmacao'));
    modal.show();
    
    document.getElementById('btnConfirmarAcao').onclick = function() {
        excluirTransacao(tipo, index);
        modal.hide();
    };
}

// Excluir transação
function excluirTransacao(tipo, index) {
    if (tipo === 'receber') {
        dadosFluxo.receber.splice(index, 1);
    } else {
        dadosFluxo.pagar.splice(index, 1);
    }
    
    // Salvar dados
    salvarDados(dadosFluxo);
    
    // Atualizar interface
    atualizarTabelas();
    atualizarResumo();
    atualizarGrafico();
    atualizarSaldoDia();
    atualizarProjecao();
    atualizarProximosVencimentos();
    atualizarGraficoCategorias();
    atualizarGraficoEvolucaoSaldo();
}

// Confirmar limpeza de todas as transações
function confirmarLimparTudo() {
    document.getElementById('mensagemConfirmacao').textContent = 'Tem certeza que deseja excluir TODAS as transações? Esta ação não pode ser desfeita.';
    
    const modal = new bootstrap.Modal(document.getElementById('modalConfirmacao'));
    modal.show();
    
    document.getElementById('btnConfirmarAcao').onclick = function() {
        limparTodasTransacoes();
        modal.hide();
    };
}

// Limpar todas as transações
function limparTodasTransacoes() {
    // Reiniciar dados
    dadosFluxo = { receber: [], pagar: [] };
    
    // Salvar dados
    salvarDados(dadosFluxo);
    
    // Atualizar interface
    atualizarTabelas();
    atualizarResumo();
    atualizarGrafico();
    atualizarSaldoDia();
    atualizarProjecao();
    atualizarProximosVencimentos();
    atualizarGraficoCategorias();
    atualizarGraficoEvolucaoSaldo();
    
    // Mostrar mensagem de sucesso
    mostrarAlerta('Todas as transações foram excluídas com sucesso!', 'success');
}

// Atualizar tabelas
function atualizarTabelas() {
    // Atualizar tabela de recebimentos
    atualizarTabela('tabelaReceber', dadosFluxo.receber, 'receber');
    
    // Atualizar tabela de pagamentos
    atualizarTabela('tabelaPagar', dadosFluxo.pagar, 'pagar');
}

// Atualizar tabela específica
function atualizarTabela(idTabela, dados, tipo) {
    const tabela = document.getElementById(idTabela);
    const tbody = tabela.querySelector('tbody');
    
    // Limpar tabela
    tbody.innerHTML = '';
    
    // Verificar se há dados
    if (dados.length === 0) {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td colspan="5" class="text-center">Nenhuma transação encontrada</td>`;
        tbody.appendChild(tr);
        return;
    }
    
    // Ordenar dados por data
    const dadosOrdenados = [...dados].sort((a, b) => new Date(a.data) - new Date(b.data));
    
    // Preencher tabela
    dadosOrdenados.forEach((item, index) => {
        const tr = document.createElement('tr');
        
        // Formatar data
        let dataFormatada = '';
        if (typeof configuracoes !== 'undefined') {
            dataFormatada = configuracoes.formatarData(new Date(item.data));
        } else {
            const data = new Date(item.data);
            dataFormatada = data.toLocaleDateString('pt-BR');
        }
        
        // Formatar valor
        let valorFormatado = '';
        if (typeof configuracoes !== 'undefined') {
            valorFormatado = configuracoes.formatarValor(item.valor);
        } else {
            valorFormatado = item.valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        
        // Obter categoria
        const categoria = item.categoria || 'Outros';
        
        tr.innerHTML = `
            <td>${dataFormatada}</td>
            <td>${valorFormatado}</td>
            <td>${item.referencia}</td>
            <td>${categoria}</td>
            <td>
                <button class="btn btn-sm btn-primary me-1" data-tipo="${tipo}" data-index="${index}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger" data-tipo="${tipo}" data-index="${index}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tbody.appendChild(tr);
    });
}

// Atualizar resumo
function atualizarResumo() {
    // Calcular totais
    const totalReceber = dadosFluxo.receber.reduce((total, item) => total + item.valor, 0);
    const totalPagar = dadosFluxo.pagar.reduce((total, item) => total + item.valor, 0);
    
    // Obter saldo inicial
    let saldoInicial = 0;
    if (typeof configuracoes !== 'undefined') {
        saldoInicial = configuracoes.obterSaldoInicial().valor;
    }
    
    const saldo = saldoInicial + totalReceber - totalPagar;
    
    // Formatar valores
    let totalReceberFormatado = '';
    let totalPagarFormatado = '';
    let saldoFormatado = '';
    
    if (typeof configuracoes !== 'undefined') {
        totalReceberFormatado = configuracoes.formatarValor(totalReceber);
        totalPagarFormatado = configuracoes.formatarValor(totalPagar);
        saldoFormatado = configuracoes.formatarValor(saldo);
    } else {
        totalReceberFormatado = totalReceber.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        totalPagarFormatado = totalPagar.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        saldoFormatado = saldo.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }
    
    // Atualizar elementos
    document.getElementById('totalReceber').textContent = totalReceberFormatado;
    document.getElementById('totalPagar').textContent = totalPagarFormatado;
    
    const saldoElement = document.getElementById('saldoTotal');
    saldoElement.textContent = saldoFormatado;
    
    // Definir classe baseada no saldo
    if (saldo > 0) {
        saldoElement.className = 'text-success';
    } else if (saldo < 0) {
        saldoElement.className = 'text-danger';
    } else {
        saldoElement.className = 'text-muted';
    }
}

// Aplicar filtro
function aplicarFiltro() {
    const dataInicio = document.getElementById('filtroDataInicio').value;
    const dataFim = document.getElementById('filtroDataFim').value;
    const tipo = document.getElementById('filtroTipo').value;
    const referencia = document.getElementById('filtroReferencia').value.toUpperCase();
    const categoria = document.getElementById('filtroCategoria').value;
    
    // Carregar todos os dados
    const todosDados = carregarDados();
    
    // Filtrar dados
    let dadosFiltrados = {
        receber: [...todosDados.receber],
        pagar: [...todosDados.pagar]
    };
    
    // Filtrar por data
    if (dataInicio) {
        const dataInicioObj = new Date(dataInicio);
        dadosFiltrados.receber = dadosFiltrados.receber.filter(item => new Date(item.data) >= dataInicioObj);
        dadosFiltrados.pagar = dadosFiltrados.pagar.filter(item => new Date(item.data) >= dataInicioObj);
    }
    
    if (dataFim) {
        const dataFimObj = new Date(dataFim);
        dataFimObj.setHours(23, 59, 59, 999);
        dadosFiltrados.receber = dadosFiltrados.receber.filter(item => new Date(item.data) <= dataFimObj);
        dadosFiltrados.pagar = dadosFiltrados.pagar.filter(item => new Date(item.data) <= dataFimObj);
    }
    
    // Filtrar por tipo
    if (tipo === 'receber') {
        dadosFiltrados.pagar = [];
    } else if (tipo === 'pagar') {
        dadosFiltrados.receber = [];
    }
    
    // Filtrar por referência
    if (referencia) {
        dadosFiltrados.receber = dadosFiltrados.receber.filter(item => 
            item.referencia.toUpperCase().includes(referencia)
        );
        dadosFiltrados.pagar = dadosFiltrados.pagar.filter(item => 
            item.referencia.toUpperCase().includes(referencia)
        );
    }
    
    // Filtrar por categoria
    if (categoria && categoria !== 'todos') {
        dadosFiltrados.receber = dadosFiltrados.receber.filter(item => 
            (item.categoria || 'outros') === categoria
        );
        dadosFiltrados.pagar = dadosFiltrados.pagar.filter(item => 
            (item.categoria || 'outros') === categoria
        );
    }
    
    // Atualizar dados
    dadosFluxo = dadosFiltrados;
    
    // Atualizar interface
    atualizarTabelas();
    atualizarResumo();
    atualizarGrafico();
    atualizarGraficoCategorias();
}

// Limpar filtro
function limparFiltro() {
    console.log('Limpando filtros...');
    
    // Limpar campos de filtro
    document.getElementById('filtroDataInicio').value = '';
    document.getElementById('filtroDataFim').value = '';
    document.getElementById('filtroTipo').value = 'todos';
    document.getElementById('filtroReferencia').value = '';
    document.getElementById('filtroCategoria').value = 'todos';
    document.getElementById('filtroIntervaloPredefinido').value = '';
    
    // Reconfigurar datas iniciais
    configurarDatasIniciais();
    
    // Carregar todos os dados
    dadosFluxo = carregarDados();
    
    // Atualizar interface
    atualizarTabelas();
    atualizarResumo();
    atualizarGrafico();
    atualizarSaldoDia();
    atualizarProjecao();
    atualizarProximosVencimentos();
    atualizarGraficoCategorias();
    atualizarGraficoEvolucaoSaldo();
    
    console.log('Filtros limpos e dados recarregados com sucesso');
}

// Aplicar intervalo predefinido
function aplicarIntervaloPredefinido() {
    const intervalo = document.getElementById('filtroIntervaloPredefinido').value;
    const hoje = new Date();
    let dataInicio, dataFim;
    
    switch (intervalo) {
        case 'hoje':
            dataInicio = dataFim = formatarDataParaInput(hoje);
            break;
        case 'ontem':
            const ontem = new Date(hoje);
            ontem.setDate(ontem.getDate() - 1);
            dataInicio = dataFim = formatarDataParaInput(ontem);
            break;
        case 'esta_semana':
            const inicioSemana = new Date(hoje);
            inicioSemana.setDate(hoje.getDate() - hoje.getDay());
            dataInicio = formatarDataParaInput(inicioSemana);
            dataFim = formatarDataParaInput(hoje);
            break;
        case 'semana_passada':
            const inicioSemanaPassada = new Date(hoje);
            inicioSemanaPassada.setDate(hoje.getDate() - hoje.getDay() - 7);
            const fimSemanaPassada = new Date(hoje);
            fimSemanaPassada.setDate(hoje.getDate() - hoje.getDay() - 1);
            dataInicio = formatarDataParaInput(inicioSemanaPassada);
            dataFim = formatarDataParaInput(fimSemanaPassada);
            break;
        case 'este_mes':
            dataInicio = formatarDataParaInput(new Date(hoje.getFullYear(), hoje.getMonth(), 1));
            dataFim = formatarDataParaInput(hoje);
            break;
        case 'mes_passado':
            dataInicio = formatarDataParaInput(new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1));
            dataFim = formatarDataParaInput(new Date(hoje.getFullYear(), hoje.getMonth(), 0));
            break;
        case 'este_ano':
            dataInicio = formatarDataParaInput(new Date(hoje.getFullYear(), 0, 1));
            dataFim = formatarDataParaInput(hoje);
            break;
        case 'ano_passado':
            dataInicio = formatarDataParaInput(new Date(hoje.getFullYear() - 1, 0, 1));
            dataFim = formatarDataParaInput(new Date(hoje.getFullYear() - 1, 11, 31));
            break;
        default:
            return;
    }
    
    document.getElementById('filtroDataInicio').value = dataInicio;
    document.getElementById('filtroDataFim').value = dataFim;
    
    aplicarFiltro();
}

// Alternar tema
function alternarTema() {
    if (typeof configuracoes !== 'undefined') {
        const temaAtual = configuracoes.temaTemaEscuro();
        configuracoes.definirTema(!temaAtual);
    } else {
        const body = document.body;
        body.classList.toggle('tema-escuro');
        
        // Salvar preferência no localStorage
        const temaEscuro = body.classList.contains('tema-escuro');
        localStorage.setItem('tema_escuro', temaEscuro);
    }
}

// Exportar dados para CSV
function exportarCSV() {
    // Carregar todos os dados
    const todosDados = carregarDados();
    
    // Criar cabeçalho
    let csv = 'Tipo,Data,Valor,Referencia,Categoria\n';
    
    // Adicionar dados de recebimentos
    todosDados.receber.forEach(item => {
        csv += `receber,${item.data},${item.valor},"${item.referencia}","${item.categoria || 'outros'}"\n`;
    });
    
    // Adicionar dados de pagamentos
    todosDados.pagar.forEach(item => {
        csv += `pagar,${item.data},${item.valor},"${item.referencia}","${item.categoria || 'outros'}"\n`;
    });
    
    // Criar blob e link para download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'fluxo_caixa_export.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Importar dados de CSV
function importarCSV(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const conteudo = e.target.result;
        const linhas = conteudo.split('\n');
        
        // Verificar se há cabeçalho
        if (linhas.length < 2) {
            mostrarAlerta('Arquivo CSV inválido ou vazio', 'danger');
            return;
        }
        
        // Verificar se o formato é compatível
        const cabecalho = linhas[0].toLowerCase();
        if (!cabecalho.includes('tipo') || !cabecalho.includes('data') || !cabecalho.includes('valor')) {
            mostrarAlerta('Formato de CSV incompatível', 'danger');
            return;
        }
        
        // Perguntar se deseja substituir ou adicionar
        if (confirm('Deseja substituir os dados existentes? Clique em OK para substituir ou Cancelar para adicionar aos dados existentes.')) {
            dadosFluxo = { receber: [], pagar: [] };
        }
        
        // Processar linhas
        let sucessos = 0;
        let erros = 0;
        
        for (let i = 1; i < linhas.length; i++) {
            const linha = linhas[i].trim();
            if (!linha) continue;
            
            try {
                // Dividir a linha considerando as aspas para campos com vírgulas
                const campos = linha.match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g);
                if (!campos || campos.length < 3) {
                    erros++;
                    continue;
                }
                
                // Remover aspas
                const tipo = campos[0].replace(/"/g, '').trim().toLowerCase();
                const data = campos[1].replace(/"/g, '').trim();
                const valor = parseFloat(campos[2].replace(/"/g, '').trim());
                const referencia = campos[3] ? campos[3].replace(/"/g, '').trim() : '';
                const categoria = campos[4] ? campos[4].replace(/"/g, '').trim() : 'outros';
                
                if (isNaN(valor) || !data) {
                    erros++;
                    continue;
                }
                
                // Criar transação
                const transacao = {
                    data: data,
                    valor: valor,
                    referencia: referencia,
                    categoria: categoria
                };
                
                // Adicionar à lista correta
                if (tipo === 'receber') {
                    dadosFluxo.receber.push(transacao);
                    sucessos++;
                } else if (tipo === 'pagar') {
                    dadosFluxo.pagar.push(transacao);
                    sucessos++;
                } else {
                    erros++;
                }
            } catch (e) {
                console.error('Erro ao processar linha:', linha, e);
                erros++;
            }
        }
        
        // Salvar dados
        salvarDados(dadosFluxo);
        
        // Atualizar interface
        atualizarTabelas();
        atualizarResumo();
        atualizarGrafico();
        atualizarSaldoDia();
        atualizarProjecao();
        atualizarProximosVencimentos();
        atualizarGraficoCategorias();
        atualizarGraficoEvolucaoSaldo();
        
        // Mostrar resultado
        mostrarAlerta(`Importação concluída: ${sucessos} transações importadas com sucesso, ${erros} erros.`, 'success');
        
        // Limpar input
        event.target.value = '';
    };
    
    reader.readAsText(file);
}

// Atualizar gráfico de categorias
function atualizarGraficoCategorias() {
    const ctx = document.getElementById('categoriasChart').getContext('2d');
    
    // Destruir gráfico anterior se existir
    if (categoriasChart) {
        categoriasChart.destroy();
    }
    
    // Obter categorias e valores
    const categorias = {};
    
    // Processar pagamentos
    dadosFluxo.pagar.forEach(item => {
        const categoria = item.categoria || 'outros';
        if (!categorias[categoria]) {
            categorias[categoria] = 0;
        }
        categorias[categoria] += item.valor;
    });
    
    // Preparar dados para o gráfico
    const labels = Object.keys(categorias);
    const valores = Object.values(categorias);
    
    // Cores para as categorias
    const cores = [
        'rgba(255, 99, 132, 0.7)',
        'rgba(54, 162, 235, 0.7)',
        'rgba(255, 206, 86, 0.7)',
        'rgba(75, 192, 192, 0.7)',
        'rgba(153, 102, 255, 0.7)',
        'rgba(255, 159, 64, 0.7)',
        'rgba(199, 199, 199, 0.7)',
        'rgba(83, 102, 255, 0.7)',
        'rgba(40, 167, 69, 0.7)',
        'rgba(220, 53, 69, 0.7)'
    ];
    
    // Criar gráfico
    categoriasChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                label: 'Gastos por Categoria',
                data: valores,
                backgroundColor: cores.slice(0, labels.length),
                borderColor: cores.slice(0, labels.length).map(cor => cor.replace('0.7', '1')),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        boxWidth: 15,
                        padding: 10
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed !== null) {
                                if (typeof configuracoes !== 'undefined') {
                                    label += configuracoes.formatarValor(context.parsed);
                                } else {
                                    label += context.parsed.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                }
                            }
                            return label;
                        }
                    }
                }
            }
        }
    });
}

// Atualizar gráfico de evolução do saldo
function atualizarGraficoEvolucaoSaldo() {
    const ctx = document.getElementById('evolucaoSaldoChart').getContext('2d');
    
    // Destruir gráfico anterior se existir
    if (evolucaoSaldoChart) {
        evolucaoSaldoChart.destroy();
    }
    
    // Obter todos os dados
    const todosDados = carregarDados();
    
    // Obter saldo inicial
    let saldoInicial = 0;
    if (typeof configuracoes !== 'undefined') {
        saldoInicial = configuracoes.obterSaldoInicial().valor;
    }
    
    // Obter todas as datas únicas
    const todasTransacoes = [
        ...todosDados.receber.map(item => ({ ...item, tipo: 'receber' })),
        ...todosDados.pagar.map(item => ({ ...item, tipo: 'pagar' }))
    ];
    
    // Ordenar por data
    todasTransacoes.sort((a, b) => new Date(a.data) - new Date(b.data));
    
    // Agrupar por mês
    const dadosPorMes = {};
    
    todasTransacoes.forEach(item => {
        const data = new Date(item.data);
        const mesAno = `${data.getFullYear()}-${(data.getMonth() + 1).toString().padStart(2, '0')}`;
        
        if (!dadosPorMes[mesAno]) {
            dadosPorMes[mesAno] = {
                receber: 0,
                pagar: 0
            };
        }
        
        if (item.tipo === 'receber') {
            dadosPorMes[mesAno].receber += item.valor;
        } else {
            dadosPorMes[mesAno].pagar += item.valor;
        }
    });
    
    // Calcular saldo acumulado
    const labels = Object.keys(dadosPorMes).sort();
    const saldos = [];
    let saldoAcumulado = saldoInicial;
    
    labels.forEach(mesAno => {
        saldoAcumulado += dadosPorMes[mesAno].receber - dadosPorMes[mesAno].pagar;
        saldos.push(saldoAcumulado);
    });
    
    // Formatar labels para exibição
    const labelsFormatados = labels.map(mesAno => {
        const [ano, mes] = mesAno.split('-');
        const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        return `${meses[parseInt(mes) - 1]}/${ano}`;
    });
    
    // Criar gráfico
    evolucaoSaldoChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labelsFormatados,
            datasets: [{
                label: 'Saldo Acumulado',
                data: saldos,
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 2,
                fill: false,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 15,
                        padding: 10
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                if (typeof configuracoes !== 'undefined') {
                                    label += configuracoes.formatarValor(context.parsed.y);
                                } else {
                                    label += context.parsed.y.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                }
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            if (typeof configuracoes !== 'undefined') {
                                return configuracoes.formatarValor(value);
                            } else {
                                return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                            }
                        }
                    }
                }
            }
        }
    });
}

// Mostrar alerta
function mostrarAlerta(mensagem, tipo) {
    const alertaContainer = document.getElementById('alertaContainer');
    
    const alerta = document.createElement('div');
    alerta.className = `alert alert-${tipo} alert-dismissible fade show`;
    alerta.innerHTML = `
        ${mensagem}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    `;
    
    alertaContainer.appendChild(alerta);
    
    // Remover alerta após 5 segundos
    setTimeout(() => {
        alerta.classList.remove('show');
        setTimeout(() => {
            alertaContainer.removeChild(alerta);
        }, 150);
    }, 5000);
}

// Funções de login
function fazerLogin() {
    const usuario = document.getElementById('loginUsuario').value;
    const senha = document.getElementById('loginSenha').value;
    
    if (!usuario || !senha) {
        mostrarAlerta('Por favor, preencha todos os campos', 'danger');
        return;
    }
    
    // Verificar se é o primeiro login
    const usuariosCadastrados = localStorage.getItem('usuarios_cadastrados');
    
    if (!usuariosCadastrados) {
        // Primeiro login, cadastrar usuário
        const usuarios = [{
            nome: usuario,
            senha: senha
        }];
        
        localStorage.setItem('usuarios_cadastrados', JSON.stringify(usuarios));
        
        // Salvar usuário logado
        usuarioLogado = {
            nome: usuario
        };
        
        localStorage.setItem('usuario_logado', JSON.stringify(usuarioLogado));
        
        // Mostrar sistema
        document.getElementById('login-container').classList.add('d-none');
        document.getElementById('app-container').classList.remove('d-none');
        document.getElementById('usuario-nome').textContent = usuario;
        
        inicializarSistema();
        
        mostrarAlerta('Usuário cadastrado e logado com sucesso!', 'success');
    } else {
        // Verificar credenciais
        const usuarios = JSON.parse(usuariosCadastrados);
        const usuarioEncontrado = usuarios.find(u => u.nome === usuario && u.senha === senha);
        
        if (usuarioEncontrado) {
            // Salvar usuário logado
            usuarioLogado = {
                nome: usuario
            };
            
            localStorage.setItem('usuario_logado', JSON.stringify(usuarioLogado));
            
            // Mostrar sistema
            document.getElementById('login-container').classList.add('d-none');
            document.getElementById('app-container').classList.remove('d-none');
            document.getElementById('usuario-nome').textContent = usuario;
            
            inicializarSistema();
            
            mostrarAlerta('Login realizado com sucesso!', 'success');
        } else {
            mostrarAlerta('Usuário ou senha incorretos', 'danger');
        }
    }
}

function fazerLogout() {
    // Remover usuário logado
    localStorage.removeItem('usuario_logado');
    usuarioLogado = null;
    
    // Mostrar tela de login
    document.getElementById('login-container').classList.remove('d-none');
    document.getElementById('app-container').classList.add('d-none');
    
    // Limpar campos
    document.getElementById('loginUsuario').value = '';
    document.getElementById('loginSenha').value = '';
}

// Funções para carregar e salvar dados
function carregarDados() {
    let dados = { receber: [], pagar: [] };
    
    // Se o sistema de login estiver ativo, usar o usuário logado como prefixo
    const prefixo = usuarioLogado ? `fluxo_caixa_${usuarioLogado.nome}_` : 'fluxo_caixa_';
    
    const dadosSalvos = localStorage.getItem(`${prefixo}dados`);
    if (dadosSalvos) {
        try {
            dados = JSON.parse(dadosSalvos);
        } catch (e) {
            console.error('Erro ao carregar dados:', e);
        }
    }
    
    return dados;
}

function salvarDados(dados) {
    // Se o sistema de login estiver ativo, usar o usuário logado como prefixo
    const prefixo = usuarioLogado ? `fluxo_caixa_${usuarioLogado.nome}_` : 'fluxo_caixa_';
    
    localStorage.setItem(`${prefixo}dados`, JSON.stringify(dados));
}
