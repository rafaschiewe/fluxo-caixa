/**
 * Módulo para configurações do sistema
 */
const configuracoes = {
    // Configurações padrão
    config: {
        // Configurações de moeda
        moeda: {
            codigo: 'BRL',
            simbolo: 'R$',
            nome: 'Real Brasileiro',
            casasDecimais: 2,
            separadorDecimal: ',',
            separadorMilhar: '.'
        },
        // Saldo inicial
        saldoInicial: {
            valor: 0,
            data: new Date(),
            descricao: 'Saldo inicial'
        },
        // Outras configurações
        formatoData: 'DD/MM/YYYY',
        temaEscuro: false
    },

    // Lista de moedas disponíveis
    moedasDisponiveis: [
        { codigo: 'BRL', simbolo: 'R$', nome: 'Real Brasileiro', casasDecimais: 2, separadorDecimal: ',', separadorMilhar: '.' },
        { codigo: 'USD', simbolo: '$', nome: 'Dólar Americano', casasDecimais: 2, separadorDecimal: '.', separadorMilhar: ',' },
        { codigo: 'EUR', simbolo: '€', nome: 'Euro', casasDecimais: 2, separadorDecimal: ',', separadorMilhar: '.' },
        { codigo: 'GBP', simbolo: '£', nome: 'Libra Esterlina', casasDecimais: 2, separadorDecimal: '.', separadorMilhar: ',' },
        { codigo: 'JPY', simbolo: '¥', nome: 'Iene Japonês', casasDecimais: 0, separadorDecimal: '.', separadorMilhar: ',' },
        { codigo: 'CNY', simbolo: '¥', nome: 'Yuan Chinês', casasDecimais: 2, separadorDecimal: '.', separadorMilhar: ',' },
        { codigo: 'ARS', simbolo: '$', nome: 'Peso Argentino', casasDecimais: 2, separadorDecimal: ',', separadorMilhar: '.' },
        { codigo: 'CLP', simbolo: '$', nome: 'Peso Chileno', casasDecimais: 0, separadorDecimal: ',', separadorMilhar: '.' }
    ],

    /**
     * Inicializa o módulo
     */
    init: function() {
        // Carregar configurações salvas
        this.carregarConfiguracoes();
        
        // Configurar botão de alternar tema
        const btnTema = document.getElementById('btnAlternarTema');
        if (btnTema) {
            btnTema.addEventListener('click', () => {
                this.definirTema(!this.config.temaEscuro);
            });
        }
    },

    /**
     * Carrega configurações do localStorage
     */
    carregarConfiguracoes: function() {
        const configSalva = localStorage.getItem('configuracoes_sistema');
        if (configSalva) {
            try {
                const config = JSON.parse(configSalva);
                
                // Mesclar configurações salvas com padrões
                this.config = { ...this.config, ...config };
                
                // Converter string de data para objeto Date
                if (typeof this.config.saldoInicial.data === 'string') {
                    this.config.saldoInicial.data = new Date(this.config.saldoInicial.data);
                }
            } catch (e) {
                console.error('Erro ao carregar configurações do sistema:', e);
            }
        }
    },

    /**
     * Salva configurações no localStorage
     */
    salvarConfiguracoes: function() {
        localStorage.setItem('configuracoes_sistema', JSON.stringify(this.config));
    },

    /**
     * Define a moeda do sistema
     * @param {String} codigoMoeda Código da moeda (ex: BRL, USD)
     * @returns {Boolean} Sucesso da operação
     */
    definirMoeda: function(codigoMoeda) {
        // Encontrar moeda na lista de disponíveis
        const moeda = this.moedasDisponiveis.find(m => m.codigo === codigoMoeda);
        if (!moeda) {
            console.error(`Moeda com código ${codigoMoeda} não encontrada`);
            return false;
        }
        
        // Atualizar configuração
        this.config.moeda = { ...moeda };
        
        // Salvar configurações
        this.salvarConfiguracoes();
        
        return true;
    },

    /**
     * Define o saldo inicial
     * @param {Object} saldoInicial Objeto com dados do saldo inicial
     * @returns {Boolean} Sucesso da operação
     */
    definirSaldoInicial: function(saldoInicial) {
        // Validar dados
        if (saldoInicial.valor === undefined || saldoInicial.data === undefined) {
            console.error('Dados de saldo inicial incompletos');
            return false;
        }
        
        // Atualizar configuração
        this.config.saldoInicial = {
            valor: parseFloat(saldoInicial.valor),
            data: new Date(saldoInicial.data),
            descricao: saldoInicial.descricao || 'Saldo inicial'
        };
        
        // Salvar configurações
        this.salvarConfiguracoes();
        
        return true;
    },

    /**
     * Obtém a configuração de moeda atual
     * @returns {Object} Configuração de moeda
     */
    obterMoeda: function() {
        return { ...this.config.moeda };
    },

    /**
     * Obtém o saldo inicial configurado
     * @returns {Object} Configuração de saldo inicial
     */
    obterSaldoInicial: function() {
        return { 
            valor: this.config.saldoInicial.valor,
            data: new Date(this.config.saldoInicial.data),
            descricao: this.config.saldoInicial.descricao
        };
    },

    /**
     * Formata um valor monetário de acordo com a moeda configurada
     * @param {Number} valor Valor a ser formatado
     * @returns {String} Valor formatado
     */
    formatarValor: function(valor) {
        // Obter configuração de moeda
        const moeda = this.config.moeda;
        
        // Formatar valor
        try {
            return valor.toLocaleString(moeda.codigo === 'BRL' ? 'pt-BR' : 'en-US', {
                style: 'currency',
                currency: moeda.codigo,
                minimumFractionDigits: moeda.casasDecimais,
                maximumFractionDigits: moeda.casasDecimais
            });
        } catch (e) {
            // Fallback para formatação manual
            const valorFixo = valor.toFixed(moeda.casasDecimais);
            const partes = valorFixo.split('.');
            
            // Formatar parte inteira
            const parteInteira = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, moeda.separadorMilhar);
            
            // Formatar parte decimal
            const parteDecimal = partes.length > 1 ? moeda.separadorDecimal + partes[1] : '';
            
            return moeda.simbolo + ' ' + parteInteira + parteDecimal;
        }
    },

    /**
     * Formata uma data de acordo com o formato configurado
     * @param {Date} data Data a ser formatada
     * @returns {String} Data formatada
     */
    formatarData: function(data) {
        if (!data) return '';
        
        const dia = data.getDate().toString().padStart(2, '0');
        const mes = (data.getMonth() + 1).toString().padStart(2, '0');
        const ano = data.getFullYear();
        
        // Formatar de acordo com o formato configurado
        switch (this.config.formatoData) {
            case 'DD/MM/YYYY':
                return `${dia}/${mes}/${ano}`;
            case 'MM/DD/YYYY':
                return `${mes}/${dia}/${ano}`;
            case 'YYYY-MM-DD':
                return `${ano}-${mes}-${dia}`;
            default:
                return `${dia}/${mes}/${ano}`;
        }
    },

    /**
     * Define o formato de data
     * @param {String} formato Formato de data (DD/MM/YYYY, MM/DD/YYYY, YYYY-MM-DD)
     * @returns {Boolean} Sucesso da operação
     */
    definirFormatoData: function(formato) {
        // Validar formato
        const formatosValidos = ['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD'];
        if (!formatosValidos.includes(formato)) {
            console.error(`Formato de data inválido: ${formato}`);
            return false;
        }
        
        // Atualizar configuração
        this.config.formatoData = formato;
        
        // Salvar configurações
        this.salvarConfiguracoes();
        
        return true;
    },

    /**
     * Define o tema do sistema
     * @param {Boolean} escuro Se true, ativa o tema escuro
     */
    definirTema: function(escuro) {
        this.config.temaEscuro = escuro;
        this.salvarConfiguracoes();
        
        // Aplicar tema
        if (escuro) {
            document.body.classList.add('tema-escuro');
            document.getElementById('iconeTema').classList.remove('fa-moon');
            document.getElementById('iconeTema').classList.add('fa-sun');
            document.getElementById('textoTema').textContent = 'Tema Claro';
        } else {
            document.body.classList.remove('tema-escuro');
            document.getElementById('iconeTema').classList.remove('fa-sun');
            document.getElementById('iconeTema').classList.add('fa-moon');
            document.getElementById('textoTema').textContent = 'Tema Escuro';
        }
    },

    /**
     * Verifica se o tema escuro está ativo
     * @returns {Boolean} True se o tema escuro estiver ativo
     */
    temaTemaEscuro: function() {
        return this.config.temaEscuro;
    },

    /**
     * Aplica as configurações atuais à interface
     */
    aplicarConfiguracoes: function() {
        // Aplicar tema
        this.definirTema(this.config.temaEscuro);
        
        // Disparar evento de configurações atualizadas
        const evento = new CustomEvent('configuracoesAtualizadas', { 
            detail: { 
                moeda: this.config.moeda,
                saldoInicial: this.config.saldoInicial,
                formatoData: this.config.formatoData,
                temaEscuro: this.config.temaEscuro
            } 
        });
        document.dispatchEvent(evento);
    }
};

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    configuracoes.init();
    configuracoes.aplicarConfiguracoes();
});
