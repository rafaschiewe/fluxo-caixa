/**
 * Módulo para gerenciamento de saldo e projeção
 */
const saldoProjecao = {
    // Configurações padrão
    config: {
        mesesProjecao: 3
    },
    
    /**
     * Inicializa o módulo
     */
    init: function() {
        // Carregar configurações salvas
        this.carregarConfiguracoes();
        
        // Configurar eventos
        document.getElementById('btnAtualizarProjecao').addEventListener('click', () => {
            const meses = parseInt(document.getElementById('mesesProjecao').value);
            this.atualizarProjecao(meses);
        });
        
        // Atualizar saldo do dia
        this.atualizarSaldoDia();
        
        // Atualizar projeção
        this.atualizarProjecao(this.config.mesesProjecao);
    },
    
    /**
     * Carrega configurações do localStorage
     */
    carregarConfiguracoes: function() {
        const configSalva = localStorage.getItem('saldo_projecao_config');
        if (configSalva) {
            try {
                const config = JSON.parse(configSalva);
                this.config = { ...this.config, ...config };
            } catch (e) {
                console.error('Erro ao carregar configurações de saldo e projeção:', e);
            }
        }
    },
    
    /**
     * Salva configurações no localStorage
     */
    salvarConfiguracoes: function() {
        localStorage.setItem('saldo_projecao_config', JSON.stringify(this.config));
    },
    
    /**
     * Atualiza o saldo do dia
     */
    atualizarSaldoDia: function() {
        // Obter data atual
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        
        // Obter saldo inicial
        let saldoInicial = 0;
        if (typeof configuracoes !== 'undefined') {
            saldoInicial = configuracoes.obterSaldoInicial().valor;
        }
        
        // Carregar todos os dados
        const todosDados = carregarDados();
        
        // Calcular saldo até hoje
        let saldoAteHoje = saldoInicial;
        
        // Adicionar recebimentos até hoje
        todosDados.receber.forEach(item => {
            const dataItem = new Date(item.data);
            dataItem.setHours(0, 0, 0, 0);
            
            if (dataItem <= hoje) {
                saldoAteHoje += item.valor;
            }
        });
        
        // Subtrair pagamentos até hoje
        todosDados.pagar.forEach(item => {
            const dataItem = new Date(item.data);
            dataItem.setHours(0, 0, 0, 0);
            
            if (dataItem <= hoje) {
                saldoAteHoje -= item.valor;
            }
        });
        
        // Formatar saldo
        let saldoFormatado = '';
        if (typeof configuracoes !== 'undefined') {
            saldoFormatado = configuracoes.formatarValor(saldoAteHoje);
        } else {
            saldoFormatado = saldoAteHoje.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        
        // Atualizar elemento
        document.getElementById('saldoDia').textContent = saldoFormatado;
        
        // Definir classe baseada no saldo
        const saldoElement = document.getElementById('saldoDia');
        if (saldoAteHoje > 0) {
            saldoElement.className = 'text-success';
        } else if (saldoAteHoje < 0) {
            saldoElement.className = 'text-danger';
        } else {
            saldoElement.className = 'text-muted';
        }
        
        // Atualizar data de atualização
        let dataFormatada = '';
        if (typeof configuracoes !== 'undefined') {
            dataFormatada = configuracoes.formatarData(hoje);
        } else {
            dataFormatada = hoje.toLocaleDateString('pt-BR');
        }
        
        document.getElementById('dataAtualizacaoSaldo').textContent = dataFormatada;
    },
    
    /**
     * Atualiza a projeção de saldo
     * @param {Number} meses Número de meses para projeção
     */
    atualizarProjecao: function(meses) {
        // Validar meses
        meses = parseInt(meses) || 3;
        if (meses < 1) meses = 1;
        if (meses > 12) meses = 12;
        
        // Atualizar configuração
        this.config.mesesProjecao = meses;
        this.salvarConfiguracoes();
        
        // Atualizar seletor
        document.getElementById('mesesProjecao').value = meses;
        
        // Obter data atual
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        
        // Obter saldo inicial
        let saldoInicial = 0;
        if (typeof configuracoes !== 'undefined') {
            saldoInicial = configuracoes.obterSaldoInicial().valor;
        }
        
        // Carregar todos os dados
        const todosDados = carregarDados();
        
        // Calcular saldo até hoje
        let saldoAteHoje = saldoInicial;
        
        // Adicionar recebimentos até hoje
        todosDados.receber.forEach(item => {
            const dataItem = new Date(item.data);
            dataItem.setHours(0, 0, 0, 0);
            
            if (dataItem <= hoje) {
                saldoAteHoje += item.valor;
            }
        });
        
        // Subtrair pagamentos até hoje
        todosDados.pagar.forEach(item => {
            const dataItem = new Date(item.data);
            dataItem.setHours(0, 0, 0, 0);
            
            if (dataItem <= hoje) {
                saldoAteHoje -= item.valor;
            }
        });
        
        // Calcular projeção para os próximos meses
        const dataFinal = new Date(hoje);
        dataFinal.setMonth(hoje.getMonth() + meses);
        
        // Preparar dados para o gráfico
        const labels = [];
        const dados = [];
        
        // Adicionar saldo atual
        labels.push('Hoje');
        dados.push(saldoAteHoje);
        
        // Calcular saldo para cada mês
        let saldoProjetado = saldoAteHoje;
        
        for (let i = 1; i <= meses; i++) {
            const dataProjecao = new Date(hoje);
            dataProjecao.setMonth(hoje.getMonth() + i);
            
            // Adicionar recebimentos do mês
            todosDados.receber.forEach(item => {
                const dataItem = new Date(item.data);
                
                if (dataItem > hoje && dataItem <= dataProjecao) {
                    saldoProjetado += item.valor;
                }
            });
            
            // Subtrair pagamentos do mês
            todosDados.pagar.forEach(item => {
                const dataItem = new Date(item.data);
                
                if (dataItem > hoje && dataItem <= dataProjecao) {
                    saldoProjetado -= item.valor;
                }
            });
            
            // Adicionar ao gráfico
            const nomeMes = dataProjecao.toLocaleDateString('pt-BR', { month: 'short' });
            labels.push(nomeMes);
            dados.push(saldoProjetado);
        }
        
        // Atualizar gráfico
        this.atualizarGraficoProjecao(labels, dados);
    },
    
    /**
     * Atualiza o gráfico de projeção
     * @param {Array} labels Rótulos para o eixo X
     * @param {Array} dados Dados para o gráfico
     */
    atualizarGraficoProjecao: function(labels, dados) {
        const ctx = document.getElementById('projecaoChart').getContext('2d');
        
        // Destruir gráfico anterior se existir
        if (window.projecaoChart) {
            window.projecaoChart.destroy();
        }
        
        // Determinar cores baseadas nos valores
        const backgroundColors = dados.map(valor => 
            valor >= 0 ? 'rgba(40, 167, 69, 0.2)' : 'rgba(220, 53, 69, 0.2)'
        );
        
        const borderColors = dados.map(valor => 
            valor >= 0 ? 'rgba(40, 167, 69, 1)' : 'rgba(220, 53, 69, 1)'
        );
        
        // Criar gráfico
        window.projecaoChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Saldo Projetado',
                    data: dados,
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                if (typeof configuracoes !== 'undefined') {
                                    return configuracoes.formatarValor(value);
                                } else {
                                    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                }
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    if (typeof configuracoes !== 'undefined') {
                                        label += configuracoes.formatarValor(context.parsed.y);
                                    } else {
                                        label += context.parsed.y.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                                    }
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    },
    
    /**
     * Atualiza a lista de próximos vencimentos
     */
    atualizarProximosVencimentos: function() {
        const listaElement = document.getElementById('listaProximosVencimentos');
        
        // Limpar lista
        listaElement.innerHTML = '';
        
        // Obter data atual
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        
        // Data limite (próximos 30 dias)
        const dataLimite = new Date(hoje);
        dataLimite.setDate(hoje.getDate() + 30);
        
        // Carregar todos os dados
        const todosDados = carregarDados();
        
        // Filtrar transações futuras
        const transacoesFuturas = [];
        
        // Adicionar recebimentos futuros
        todosDados.receber.forEach(item => {
            const dataItem = new Date(item.data);
            dataItem.setHours(0, 0, 0, 0);
            
            if (dataItem >= hoje && dataItem <= dataLimite) {
                transacoesFuturas.push({
                    ...item,
                    tipo: 'receber',
                    data: dataItem
                });
            }
        });
        
        // Adicionar pagamentos futuros
        todosDados.pagar.forEach(item => {
            const dataItem = new Date(item.data);
            dataItem.setHours(0, 0, 0, 0);
            
            if (dataItem >= hoje && dataItem <= dataLimite) {
                transacoesFuturas.push({
                    ...item,
                    tipo: 'pagar',
                    data: dataItem
                });
            }
        });
        
        // Ordenar por data
        transacoesFuturas.sort((a, b) => a.data - b.data);
        
        // Verificar se há transações
        if (transacoesFuturas.length === 0) {
            const li = document.createElement('li');
            li.className = 'list-group-item text-center';
            li.textContent = 'Nenhum vencimento nos próximos 30 dias';
            listaElement.appendChild(li);
            return;
        }
        
        // Adicionar transações à lista
        transacoesFuturas.slice(0, 10).forEach(item => {
            const li = document.createElement('li');
            li.className = 'list-group-item d-flex justify-content-between align-items-center';
            
            // Formatar data
            let dataFormatada = '';
            if (typeof configuracoes !== 'undefined') {
                dataFormatada = configuracoes.formatarData(item.data);
            } else {
                dataFormatada = item.data.toLocaleDateString('pt-BR');
            }
            
            // Formatar valor
            let valorFormatado = '';
            if (typeof configuracoes !== 'undefined') {
                valorFormatado = configuracoes.formatarValor(item.valor);
            } else {
                valorFormatado = item.valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            }
            
            // Calcular dias restantes
            const diasRestantes = Math.ceil((item.data - hoje) / (1000 * 60 * 60 * 24));
            let textoRestante = '';
            
            if (diasRestantes === 0) {
                textoRestante = 'Hoje';
            } else if (diasRestantes === 1) {
                textoRestante = 'Amanhã';
            } else {
                textoRestante = `Em ${diasRestantes} dias`;
            }
            
            // Definir classe baseada no tipo
            const classeValor = item.tipo === 'receber' ? 'text-success' : 'text-danger';
            const icone = item.tipo === 'receber' ? 'fa-arrow-down' : 'fa-arrow-up';
            
            li.innerHTML = `
                <div>
                    <div class="fw-bold">${item.referencia || 'Sem referência'}</div>
                    <small class="text-muted">${dataFormatada} (${textoRestante})</small>
                </div>
                <span class="${classeValor}">
                    <i class="fas ${icone} me-1"></i>${valorFormatado}
                </span>
            `;
            
            listaElement.appendChild(li);
        });
        
        // Se houver mais transações, mostrar indicador
        if (transacoesFuturas.length > 10) {
            const li = document.createElement('li');
            li.className = 'list-group-item text-center text-muted';
            li.textContent = `E mais ${transacoesFuturas.length - 10} vencimentos...`;
            listaElement.appendChild(li);
        }
    }
};
