/**
 * Módulo para gerenciamento de parcelamentos
 */
const parcelamentos = {
    // Configurações padrão
    config: {
        modelosParcelamento: [
            { id: 'padrao', nome: 'Padrão (parcelas iguais)', descricao: 'Divide o valor em parcelas iguais' },
            { id: 'percentual', nome: 'Percentual', descricao: 'Define percentuais diferentes para cada parcela' },
            { id: 'adiantado', nome: 'Pagamento Adiantado', descricao: '100% do valor pago antecipadamente' },
            { id: 'prazo_bl', nome: 'Prazo após BL', descricao: 'Pagamento com prazo específico após o BL (Bill of Lading)' }
        ]
    },
    
    /**
     * Inicializa o módulo
     */
    init: function() {
        // Carregar configurações salvas
        this.carregarConfiguracoes();
        
        // Configurar eventos
        this.configurarEventos();
        
        // Carregar parcelamentos
        this.carregarParcelamentos();
    },
    
    /**
     * Carrega configurações do localStorage
     */
    carregarConfiguracoes: function() {
        const configSalva = localStorage.getItem('parcelamentos_config');
        if (configSalva) {
            try {
                const config = JSON.parse(configSalva);
                this.config = { ...this.config, ...config };
            } catch (e) {
                console.error('Erro ao carregar configurações de parcelamentos:', e);
            }
        }
    },
    
    /**
     * Salva configurações no localStorage
     */
    salvarConfiguracoes: function() {
        localStorage.setItem('parcelamentos_config', JSON.stringify(this.config));
    },
    
    /**
     * Configura eventos do módulo
     */
    configurarEventos: function() {
        // Verificar se estamos na página de parcelamentos
        const btnNovoParcelamento = document.getElementById('btnNovoParcelamento');
        if (!btnNovoParcelamento) return;
        
        // Botão de novo parcelamento
        btnNovoParcelamento.addEventListener('click', () => this.abrirModalParcelamento());
        
        // Botão de salvar parcelamento
        document.getElementById('btnSalvarParcelamento').addEventListener('click', () => this.salvarParcelamento());
        
        // Seletor de modelo de parcelamento
        document.getElementById('modeloParcelamento').addEventListener('change', () => this.atualizarCamposModelo());
        
        // Botão de adicionar parcela
        document.getElementById('btnAdicionarParcela').addEventListener('click', () => this.adicionarCampoParcela());
    },
    
    /**
     * Carrega parcelamentos salvos
     */
    carregarParcelamentos: function() {
        // Verificar se estamos na página de parcelamentos
        const tabelaParcelamentos = document.getElementById('tabelaParcelamentos');
        if (!tabelaParcelamentos) return;
        
        // Obter parcelamentos salvos
        const parcelamentosSalvos = this.obterParcelamentosSalvos();
        
        // Limpar tabela
        const tbody = tabelaParcelamentos.querySelector('tbody');
        tbody.innerHTML = '';
        
        // Verificar se há parcelamentos
        if (parcelamentosSalvos.length === 0) {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td colspan="6" class="text-center">Nenhum parcelamento encontrado</td>`;
            tbody.appendChild(tr);
            return;
        }
        
        // Preencher tabela
        parcelamentosSalvos.forEach((item, index) => {
            const tr = document.createElement('tr');
            
            // Formatar data
            let dataFormatada = '';
            if (typeof configuracoes !== 'undefined') {
                dataFormatada = configuracoes.formatarData(new Date(item.data));
            } else {
                const data = new Date(item.data);
                dataFormatada = data.toLocaleDateString('pt-BR');
            }
            
            // Formatar valor total
            let valorFormatado = '';
            if (typeof configuracoes !== 'undefined') {
                valorFormatado = configuracoes.formatarValor(item.valorTotal);
            } else {
                valorFormatado = item.valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            }
            
            // Obter nome do modelo
            const modelo = this.config.modelosParcelamento.find(m => m.id === item.modelo) || { nome: 'Desconhecido' };
            
            tr.innerHTML = `
                <td>${dataFormatada}</td>
                <td>${valorFormatado}</td>
                <td>${item.referencia}</td>
                <td>${modelo.nome}</td>
                <td>${item.parcelas.length}</td>
                <td>
                    <button class="btn btn-sm btn-primary me-1" data-index="${index}">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" data-index="${index}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            
            tbody.appendChild(tr);
            
            // Configurar eventos dos botões
            const btnVisualizar = tr.querySelector('.btn-primary');
            const btnExcluir = tr.querySelector('.btn-danger');
            
            btnVisualizar.addEventListener('click', () => this.visualizarParcelamento(index));
            btnExcluir.addEventListener('click', () => this.confirmarExclusaoParcelamento(index));
        });
    },
    
    /**
     * Obtém parcelamentos salvos
     * @returns {Array} Lista de parcelamentos
     */
    obterParcelamentosSalvos: function() {
        // Se o sistema de login estiver ativo, usar o usuário logado como prefixo
        const prefixo = window.usuarioLogado ? `parcelamentos_${window.usuarioLogado.nome}_` : 'parcelamentos_';
        
        const parcelamentosSalvos = localStorage.getItem(`${prefixo}dados`);
        if (parcelamentosSalvos) {
            try {
                return JSON.parse(parcelamentosSalvos);
            } catch (e) {
                console.error('Erro ao carregar parcelamentos:', e);
            }
        }
        
        return [];
    },
    
    /**
     * Salva parcelamentos
     * @param {Array} parcelamentos Lista de parcelamentos
     */
    salvarParcelamentosDados: function(parcelamentos) {
        // Se o sistema de login estiver ativo, usar o usuário logado como prefixo
        const prefixo = window.usuarioLogado ? `parcelamentos_${window.usuarioLogado.nome}_` : 'parcelamentos_';
        
        localStorage.setItem(`${prefixo}dados`, JSON.stringify(parcelamentos));
    },
    
    /**
     * Abre o modal de novo parcelamento
     * @param {Object} parcelamento Parcelamento existente para edição (opcional)
     */
    abrirModalParcelamento: function(parcelamento) {
        // Limpar formulário
        document.getElementById('formParcelamento').reset();
        document.getElementById('parcelamentoId').value = '';
        
        // Limpar container de parcelas
        document.getElementById('containerParcelas').innerHTML = '';
        
        // Definir data atual
        document.getElementById('parcelamentoData').valueAsDate = new Date();
        
        // Preencher seletor de modelo
        const seletorModelo = document.getElementById('modeloParcelamento');
        seletorModelo.innerHTML = '';
        
        this.config.modelosParcelamento.forEach(modelo => {
            const option = document.createElement('option');
            option.value = modelo.id;
            option.textContent = modelo.nome;
            option.title = modelo.descricao;
            seletorModelo.appendChild(option);
        });
        
        // Atualizar campos do modelo
        this.atualizarCamposModelo();
        
        // Se for edição, preencher dados
        if (parcelamento) {
            document.getElementById('parcelamentoId').value = parcelamento.id || '';
            document.getElementById('parcelamentoData').value = parcelamento.data;
            document.getElementById('parcelamentoValorTotal').value = parcelamento.valorTotal;
            document.getElementById('parcelamentoReferencia').value = parcelamento.referencia;
            document.getElementById('modeloParcelamento').value = parcelamento.modelo;
            
            // Preencher parcelas
            this.preencherParcelasExistentes(parcelamento.parcelas);
            
            // Atualizar campos do modelo
            this.atualizarCamposModelo();
            
            // Atualizar título do modal
            document.getElementById('modalParcelamentoLabel').textContent = 'Editar Parcelamento';
        } else {
            // Atualizar título do modal
            document.getElementById('modalParcelamentoLabel').textContent = 'Novo Parcelamento';
        }
        
        // Abrir modal
        const modal = new bootstrap.Modal(document.getElementById('modalParcelamento'));
        modal.show();
    },
    
    /**
     * Atualiza os campos do formulário baseado no modelo selecionado
     */
    atualizarCamposModelo: function() {
        const modeloSelecionado = document.getElementById('modeloParcelamento').value;
        const containerParcelas = document.getElementById('containerParcelas');
        const containerNumParcelas = document.getElementById('containerNumParcelas');
        const containerDataBL = document.getElementById('containerDataBL');
        
        // Limpar container de parcelas
        containerParcelas.innerHTML = '';
        
        // Mostrar/ocultar campos específicos
        switch (modeloSelecionado) {
            case 'padrao':
                containerNumParcelas.classList.remove('d-none');
                containerDataBL.classList.add('d-none');
                break;
            case 'percentual':
                containerNumParcelas.classList.add('d-none');
                containerDataBL.classList.add('d-none');
                this.adicionarCampoParcela();
                break;
            case 'adiantado':
                containerNumParcelas.classList.add('d-none');
                containerDataBL.classList.add('d-none');
                break;
            case 'prazo_bl':
                containerNumParcelas.classList.add('d-none');
                containerDataBL.classList.remove('d-none');
                break;
            default:
                containerNumParcelas.classList.remove('d-none');
                containerDataBL.classList.add('d-none');
                break;
        }
    },
    
    /**
     * Adiciona um campo de parcela ao formulário
     * @param {Object} parcela Dados da parcela existente (opcional)
     */
    adicionarCampoParcela: function(parcela) {
        const containerParcelas = document.getElementById('containerParcelas');
        const numParcela = containerParcelas.children.length + 1;
        
        const divParcela = document.createElement('div');
        divParcela.className = 'row mb-3 parcela-item';
        
        divParcela.innerHTML = `
            <div class="col-md-2">
                <label class="form-label">Parcela ${numParcela}</label>
            </div>
            <div class="col-md-3">
                <input type="date" class="form-control parcela-data" required>
            </div>
            <div class="col-md-3">
                <div class="input-group">
                    <span class="input-group-text">%</span>
                    <input type="number" class="form-control parcela-percentual" min="1" max="100" value="100" required>
                </div>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control parcela-descricao" placeholder="Descrição">
            </div>
            <div class="col-md-1">
                <button type="button" class="btn btn-danger btn-remover-parcela">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        containerParcelas.appendChild(divParcela);
        
        // Configurar evento do botão de remover
        const btnRemover = divParcela.querySelector('.btn-remover-parcela');
        btnRemover.addEventListener('click', () => {
            containerParcelas.removeChild(divParcela);
            this.renumerarParcelas();
        });
        
        // Se for parcela existente, preencher dados
        if (parcela) {
            divParcela.querySelector('.parcela-data').value = parcela.data;
            divParcela.querySelector('.parcela-percentual').value = parcela.percentual;
            divParcela.querySelector('.parcela-descricao').value = parcela.descricao || '';
        } else {
            // Definir data padrão (hoje + 30 dias * número da parcela)
            const dataBase = new Date();
            dataBase.setDate(dataBase.getDate() + (30 * numParcela));
            divParcela.querySelector('.parcela-data').valueAsDate = dataBase;
        }
    },
    
    /**
     * Renumera as parcelas após remoção
     */
    renumerarParcelas: function() {
        const containerParcelas = document.getElementById('containerParcelas');
        const parcelas = containerParcelas.querySelectorAll('.parcela-item');
        
        parcelas.forEach((parcela, index) => {
            const label = parcela.querySelector('.form-label');
            label.textContent = `Parcela ${index + 1}`;
        });
    },
    
    /**
     * Preenche parcelas existentes no formulário
     * @param {Array} parcelas Lista de parcelas
     */
    preencherParcelasExistentes: function(parcelas) {
        parcelas.forEach(parcela => {
            this.adicionarCampoParcela(parcela);
        });
    },
    
    /**
     * Salva o parcelamento
     */
    salvarParcelamento: function() {
        // Validar formulário
        const form = document.getElementById('formParcelamento');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        // Obter dados do formulário
        const id = document.getElementById('parcelamentoId').value;
        const data = document.getElementById('parcelamentoData').value;
        const valorTotal = parseFloat(document.getElementById('parcelamentoValorTotal').value);
        const referencia = document.getElementById('parcelamentoReferencia').value;
        const modelo = document.getElementById('modeloParcelamento').value;
        
        // Obter parcelas
        let parcelas = [];
        
        switch (modelo) {
            case 'padrao':
                // Obter número de parcelas
                const numParcelas = parseInt(document.getElementById('numParcelas').value);
                
                // Calcular valor por parcela
                const valorParcela = valorTotal / numParcelas;
                
                // Criar parcelas
                for (let i = 0; i < numParcelas; i++) {
                    const dataParcela = new Date(data);
                    dataParcela.setMonth(dataParcela.getMonth() + i);
                    
                    parcelas.push({
                        data: dataParcela.toISOString().split('T')[0],
                        percentual: 100 / numParcelas,
                        valor: valorParcela,
                        descricao: `Parcela ${i + 1} de ${numParcelas}`
                    });
                }
                break;
            case 'percentual':
                // Obter parcelas do formulário
                const parcelasItems = document.querySelectorAll('.parcela-item');
                
                parcelasItems.forEach((item, index) => {
                    const dataParcela = item.querySelector('.parcela-data').value;
                    const percentual = parseFloat(item.querySelector('.parcela-percentual').value);
                    const descricao = item.querySelector('.parcela-descricao').value;
                    
                    parcelas.push({
                        data: dataParcela,
                        percentual: percentual,
                        valor: (valorTotal * percentual) / 100,
                        descricao: descricao || `Parcela ${index + 1}`
                    });
                });
                break;
            case 'adiantado':
                // Criar uma única parcela com 100%
                parcelas.push({
                    data: data,
                    percentual: 100,
                    valor: valorTotal,
                    descricao: 'Pagamento adiantado (100%)'
                });
                break;
            case 'prazo_bl':
                // Obter data do BL
                const dataBL = document.getElementById('dataBL').value;
                
                // Obter prazo em dias
                const prazoDias = parseInt(document.getElementById('prazoDias').value);
                
                // Calcular data de vencimento
                const dataVencimento = new Date(dataBL);
                dataVencimento.setDate(dataVencimento.getDate() + prazoDias);
                
                // Criar parcela
                parcelas.push({
                    data: dataVencimento.toISOString().split('T')[0],
                    percentual: 100,
                    valor: valorTotal,
                    descricao: `Pagamento ${prazoDias} dias após BL`
                });
                break;
        }
        
        // Criar objeto de parcelamento
        const parcelamento = {
            data: data,
            valorTotal: valorTotal,
            referencia: referencia,
            modelo: modelo,
            parcelas: parcelas
        };
        
        // Obter parcelamentos salvos
        const parcelamentosSalvos = this.obterParcelamentosSalvos();
        
        // Adicionar ou atualizar parcelamento
        if (id) {
            // Atualizar parcelamento existente
            const index = parseInt(id);
            if (index >= 0 && index < parcelamentosSalvos.length) {
                parcelamentosSalvos[index] = parcelamento;
            }
        } else {
            // Adicionar novo parcelamento
            parcelamentosSalvos.push(parcelamento);
        }
        
        // Salvar parcelamentos
        this.salvarParcelamentosDados(parcelamentosSalvos);
        
        // Atualizar tabela
        this.carregarParcelamentos();
        
        // Fechar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalParcelamento'));
        modal.hide();
        
        // Mostrar mensagem de sucesso
        alert('Parcelamento salvo com sucesso!');
    },
    
    /**
     * Visualiza um parcelamento
     * @param {Number} index Índice do parcelamento
     */
    visualizarParcelamento: function(index) {
        // Obter parcelamentos salvos
        const parcelamentosSalvos = this.obterParcelamentosSalvos();
        
        // Verificar se o índice é válido
        if (index < 0 || index >= parcelamentosSalvos.length) {
            alert('Parcelamento não encontrado!');
            return;
        }
        
        // Obter parcelamento
        const parcelamento = parcelamentosSalvos[index];
        
        // Abrir modal de visualização
        this.abrirModalVisualizacaoParcelamento(parcelamento);
    },
    
    /**
     * Abre o modal de visualização de parcelamento
     * @param {Object} parcelamento Parcelamento a ser visualizado
     */
    abrirModalVisualizacaoParcelamento: function(parcelamento) {
        // Obter elementos do modal
        const modalBody = document.getElementById('modalVisualizacaoParcelamentoBody');
        
        // Limpar conteúdo
        modalBody.innerHTML = '';
        
        // Formatar data
        let dataFormatada = '';
        if (typeof configuracoes !== 'undefined') {
            dataFormatada = configuracoes.formatarData(new Date(parcelamento.data));
        } else {
            const data = new Date(parcelamento.data);
            dataFormatada = data.toLocaleDateString('pt-BR');
        }
        
        // Formatar valor total
        let valorFormatado = '';
        if (typeof configuracoes !== 'undefined') {
            valorFormatado = configuracoes.formatarValor(parcelamento.valorTotal);
        } else {
            valorFormatado = parcelamento.valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        }
        
        // Obter nome do modelo
        const modelo = this.config.modelosParcelamento.find(m => m.id === parcelamento.modelo) || { nome: 'Desconhecido' };
        
        // Criar conteúdo
        const divInfo = document.createElement('div');
        divInfo.className = 'mb-4';
        divInfo.innerHTML = `
            <h5>Informações Gerais</h5>
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Data:</strong> ${dataFormatada}</p>
                    <p><strong>Valor Total:</strong> ${valorFormatado}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Referência:</strong> ${parcelamento.referencia}</p>
                    <p><strong>Modelo:</strong> ${modelo.nome}</p>
                </div>
            </div>
        `;
        
        modalBody.appendChild(divInfo);
        
        // Criar tabela de parcelas
        const divParcelas = document.createElement('div');
        divParcelas.innerHTML = `
            <h5>Parcelas</h5>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Data</th>
                            <th>Percentual</th>
                            <th>Valor</th>
                            <th>Descrição</th>
                        </tr>
                    </thead>
                    <tbody id="tabelaParcelasVisualizacao"></tbody>
                </table>
            </div>
        `;
        
        modalBody.appendChild(divParcelas);
        
        // Preencher tabela de parcelas
        const tbody = document.getElementById('tabelaParcelasVisualizacao');
        
        parcelamento.parcelas.forEach((parcela, index) => {
            const tr = document.createElement('tr');
            
            // Formatar data
            let dataParcelaFormatada = '';
            if (typeof configuracoes !== 'undefined') {
                dataParcelaFormatada = configuracoes.formatarData(new Date(parcela.data));
            } else {
                const dataParcela = new Date(parcela.data);
                dataParcelaFormatada = dataParcela.toLocaleDateString('pt-BR');
            }
            
            // Formatar valor
            let valorParcelaFormatado = '';
            if (typeof configuracoes !== 'undefined') {
                valorParcelaFormatado = configuracoes.formatarValor(parcela.valor);
            } else {
                valorParcelaFormatado = parcela.valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            }
            
            tr.innerHTML = `
                <td>${index + 1}</td>
                <td>${dataParcelaFormatada}</td>
                <td>${parcela.percentual}%</td>
                <td>${valorParcelaFormatado}</td>
                <td>${parcela.descricao || '-'}</td>
            `;
            
            tbody.appendChild(tr);
        });
        
        // Abrir modal
        const modal = new bootstrap.Modal(document.getElementById('modalVisualizacaoParcelamento'));
        modal.show();
    },
    
    /**
     * Confirma a exclusão de um parcelamento
     * @param {Number} index Índice do parcelamento
     */
    confirmarExclusaoParcelamento: function(index) {
        if (confirm('Tem certeza que deseja excluir este parcelamento?')) {
            this.excluirParcelamento(index);
        }
    },
    
    /**
     * Exclui um parcelamento
     * @param {Number} index Índice do parcelamento
     */
    excluirParcelamento: function(index) {
        // Obter parcelamentos salvos
        const parcelamentosSalvos = this.obterParcelamentosSalvos();
        
        // Verificar se o índice é válido
        if (index < 0 || index >= parcelamentosSalvos.length) {
            alert('Parcelamento não encontrado!');
            return;
        }
        
        // Remover parcelamento
        parcelamentosSalvos.splice(index, 1);
        
        // Salvar parcelamentos
        this.salvarParcelamentosDados(parcelamentosSalvos);
        
        // Atualizar tabela
        this.carregarParcelamentos();
        
        // Mostrar mensagem de sucesso
        alert('Parcelamento excluído com sucesso!');
    }
};

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    parcelamentos.init();
});
